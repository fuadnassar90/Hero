'use strict';
const service = require('./App/Service/service')
const tempInfo = require('./App/Entity/TempInfo');
const express = require('express');
const socketIO = require('socket.io');
const controller = require('./App/Controller/controller');
const PORT = process.env.PORT || 8080;
const INDEX = '/index.html';

const {
    Client
} = require('pg');
const db = new Client({
    user: "biapwskdrvyjfh",
    password: "fd0bcc9345f8e1123b54531c40199903d370c370844ab9034aca1876d763d378",
    host: "ec2-54-155-226-153.eu-west-1.compute.amazonaws.com",
    port: "5432",
    database: "dfrogsh6j94e5v",
    ssl: {
        rejectUnauthorized: false
    }
});
db.connect();

const server = express()
    .use([express.urlencoded({
        extended: true
    }), express.json()])
    .use("/app", controller)
    .use("/", (req, res) => res.sendFile(INDEX, {
        root: __dirname
    }))
    .listen(PORT, () => console.log(`Listening on ${PORT}`));
const io = socketIO(server);


io.on('connection', function(socket) {
    socket.id_auth = socket.handshake.query.id + "";
    socket.id_route = socket.handshake.query.id_route + "";
    socket.account_type = socket.handshake.query.type + "";
    socket.location = socket.handshake.query.location + "";

//    console.log('socket.id:' + socket.id);
//    console.log('socket.id_auth:' + socket.id);
//    console.log('socket.id_route:' + socket.id_route);
//    console.log('socket.location:' + socket.location);
//    console.log('-----------------------------');
//    socket.id_route='1';

    console.log('There is new connected ' + socket.id + ' and type ' + socket.account_type);
    socket.join(socket.id_route);

    socket.on('disconnect', () => {
        console.log('disconnected ' + socket.id + ' and type ' + socket.account_type);
        if (socket.account_type == "user") {
            io.sockets.in(socket.id_route).emit('map_users', {
                action: "delete",
                id: "user." + socket.id,
                location: ""
            });
            tempInfo.deleteUser(socket.id_route, socket.id);
        } else {
            io.sockets.in(socket.id_route).emit('map_drivers', {
                action: "delete",
                id: "driver." + socket.id,
                location: ""
            });
            tempInfo.deleteDriver(socket.id_route, socket.id);

            db.query("UPDATE buses_info set is_work_now=false where id=" + socket.id + " ", (err, res) => {
                if (err) {
                    console.log(err);
                }
                db.query("UPDATE routes_info set current_work_buses=(select count(*) from buses_info where id_route=" + socket.id_route + " and is_work_now='true') where id=" + socket.id_route + " RETURNING current_work_buses;", (err, res) => {
                    if (err) {
                        console.log(err);
                    }
                });
            });

        }
        socket.leave(socket.id_route);
    });
    socket.on('map_users', function(data) {
        console.log('run socket.on map_users');
        io.sockets.in(socket.id_route).emit('map_users', {
            action: "update",
            id: "user." + socket.id,
            location: data.location
        });
        tempInfo.addOrUpdateUser(socket.id_route, socket.id, data.location);
    });
    socket.on('map_drivers', function(data) {
        console.log('run socket.on map_drivers');
        io.sockets.in(socket.id_route).emit('map_drivers', {
            action: "update",
            id: "driver." + socket.id,
            location: data.location
        });
        tempInfo.addOrUpdateDriver(socket.id_route, socket.id, data.location);
    });

    if (socket.account_type == "user") {
        io.sockets.in(socket.id_route).emit('map_users', {
            action: "add",
            id: "user." + socket.id,
            location: socket.location
        });
        tempInfo.addOrUpdateUser(socket.id_route, socket.id, socket.location);
    } else {
        io.sockets.in(socket.id_route).emit('map_drivers', {
            action: "add",
            id: "driver." + socket.id,
            location: socket.location
        });
        tempInfo.addOrUpdateDriver(socket.id_route, socket.id, socket.location);

           db.query("UPDATE buses_info set is_work_now=true where id=" + socket.id_auth + " ", (err, res) => {
                       if (err) {
                           console.log(err);
                       }
                       db.query("UPDATE routes_info set current_work_buses=(select count(*) from buses_info where id_route=" + socket.id_route + " and is_work_now='true') where id=" + socket.id_route + " RETURNING current_work_buses;", (err, res) => {
                           if (err) {
                               console.log(err);
                           }
                       });
                   });

                    }




});


module.exports = server;