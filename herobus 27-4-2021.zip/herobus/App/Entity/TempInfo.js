var all_users_temp_info = new Map();
var all_buses_temp_info = new Map();
var users_temp_info = new Map();
var buses_temp_info = new Map();

function isExist(map, key) {
    return map.get(key) != null;
}

module.exports = {
    addOrUpdateUser: (id_route, id_user, loc) => {
        var map = all_users_temp_info.get(id_route);
        if (map != null) {
            map.set(id_user, loc);
        } else {
            var map_temp = new Map();
            map_temp.set(id_user, loc);
            all_users_temp_info.set(id_route, map_temp);
        }
    },
    deleteUser: (id_route, id_user) => {
        var map = all_users_temp_info.get(id_route);
        if (map != null) {
            map.delete(id_user);
        }
    },
    getUsersTempInfo: (id_route) => {
      var map = all_users_temp_info.get(id_route);
            if (map != null) {
                return Array.from(map.entries());
            } else {
                return [];
            }
    },
    addOrUpdateDriver: (id_route, id_driver, loc) => {
        var map = all_buses_temp_info.get(id_route);
        if (map != null) {
            map.set(id_driver, loc);

        } else {
            var map_temp = new Map();
            map_temp.set(id_driver, loc);
            all_buses_temp_info.set(id_route, map_temp);
        }
    },
    deleteDriver: (id_route, id_driver) => {
        var map = all_buses_temp_info.get(id_route);
        if (map != null) {
            map.delete(id_driver);
        }
    },

    getBusesTempInfo: (id_route) => {
        var map = all_buses_temp_info.get(id_route);
        if (map != null) {
            return Array.from(map.entries());
        } else {
            return [];
        }

    },
//    setTempInfo: () => {
//    console.log("set temp values");
//             buses_temp_info.set("3", "4554");
////             buses_temp_info.set("6", "7878");
//        users_temp_info.set("34", "23");
//        users_temp_info.set("565", "45");
//         }
}