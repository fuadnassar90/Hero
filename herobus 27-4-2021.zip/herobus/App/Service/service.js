//const { static } = require('express');
//const express = require('express');
const request = require('request');
const tempInfo = require('../Entity/TempInfo');
const jwt = require('jsonwebtoken');
const compareVersions = require('compare-versions');
var phoneToken = require('generate-sms-verification-code')
const {
    encrypt,
    decrypt,
    isMatch
} = require.main.require('./mylib/crypto');
//const encrypt = require.main.require('./mylib/crpyto.js');
const NodeRSA = require('node-rsa');
const ACCESS_TOKEN_SECRET = 'd38c6bdd6d406c331cd94d6f63480097e12894957b041aabe957ebfb257ad352dda35e956206da30e2d9c8f1716adfeda5a205b35b5662a4df48c472f925b960'
const key = new NodeRSA({
    b: 512
});
const {
    Client
} = require('pg');
const db = new Client({
    user: "biapwskdrvyjfh",
    password: "fd0bcc9345f8e1123b54531c40199903d370c370844ab9034aca1876d763d378",
    host: "ec2-54-155-226-153.eu-west-1.compute.amazonaws.com",
    port: "5432",
    database: "dfrogsh6j94e5v",
    ssl: {
        rejectUnauthorized: false
    }
});
db.connect();

module.exports = {
    getDatabase() {
        return db;
    },
    driverAuthToken: (req, resApi, next) => {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];
        if (token == null) return res.sendStatus(401);
        jwt.verify(token, ACCESS_TOKEN_SECRET, (err, payload) => {
            if (err){ return res.sendStatus(403);}else{
            req.payload = payload;
            db.query("SELECT pass FROM drivers_info WHERE phone='" + req.payload.phone + "'", (err, res) => {
                if (err || res.rows.length==0) throw err;
                if (isMatch(req.payload.pass, res.rows[0].pass)) {
                    next();
                } else {
                    resApi.status(403).send("الخطأ: تم تغير كلمة السر");
                }
            });
}
        });
    },
    userAuthToken: (req, resApi, next) => {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];
        if (token == null) return res.sendStatus(401);
        jwt.verify(token, ACCESS_TOKEN_SECRET, (err, payload) => {
            if (err){ return resApi.sendStatus(403);}else{
            req.payload = payload;
            next();
            }
        });
    },
    test: (req, resApi) => {
        resApi.json({
            message: "test driver function"
        });

    },
    addBusOrder: (req, resApi) => {

        const sql1 = {
            text: 'INSERT INTO buses_info(name,no_plate,is_verified,is_push_enable,is_work_now,drivers_count,push_token) values($1,$2,$3,$4,$5,$6,$7) RETURNING id;',
            values: [req.body.name_route, req.body.no_plate, false, true, false, 1, req.body.push_token],
        };
        db.query(sql1, (err, res1) => {
            if (err || res1.rows.length==0) {
                const errMsg = err.message;
                console.log(errMsg);
                if (errMsg.includes('unique constraint')) {
                    resApi.status(400).send("الخطأ: رقم لوحة الحافلة مسجل مسبقا");
                } else {
                    resApi.status(500).send("الخطأ: يوجد مشكلة في بيانات الحافلة");
                }
            } else {
                const sql2 = {
                    text: 'INSERT INTO drivers_info(id_bus,phone,pass) values($1,$2,$3)',
                    values: [res1.rows[0].id, req.body.phone, encrypt(req.body.pass)],
                };


                db.query(sql2, (err, res2) => {

                    if (err || res1.rows.length==0) {
                        db.query("delete from buses_info where id=" + res1.rows[0].id, (err, res) => {
                            if (err) throw err;
                        });

                        const errMsg = err.message;
                        console.log(errMsg);
                        if (errMsg.includes('unique constraint')) {
                            resApi.status(400).send("الخطأ: رقم الهاتف مسجل مسبقا, يجب التسجيل برقم مختلف");
                        } else {
                            resApi.status(500).send("الخطأ: يوجد مشكلة في بيانات السائق");
                        }
                    } else {
                        const ACCESS_TOKEN = jwt.sign({
                            phone: req.body.phone,
                            pass: encrypt(req.body.pass)
                        }, ACCESS_TOKEN_SECRET);
                        resApi.send(ACCESS_TOKEN);
                    }

                });
            }


        });

    },
    getAllBusesOrders: (req, resApi) => {
        db.query("select * from buses_info where is_verified='false' ORDER BY id DESC", (err, res) => {
            if (err) throw err;
            resApi.send(res.rows);
        });
    },
    acceptBusOrder: (req, resApi) => {
        const id_bus = req.body.id_bus;
        const id_route = req.body.id_route;
        db.query("SELECT COUNT(*) from routes_info where id=" + id_route, (err, res) => {
            if (err) throw err;
            const isExist = (res.rows[0].count > 0);
            if (isExist) {
                //executeQuery("UPDATE routes_info SET count_buses = count_buses + 1 WHERE id ="+id_route);
                db.query("UPDATE routes_info SET count_buses = count_buses + 1 WHERE id = " + id_route + " RETURNING count_buses;", (err, res) => {
                    if (err) throw err;
                    const count_buses = res.rows[0].count_buses;
                    const name_bus = "B" + count_buses;
                    executeQuery("UPDATE buses_info SET name='" + name_bus + "',is_verified=true where id=" + id_bus);
                    ///-------------------------- Should send push notification to drivers
                    resApi.send("done");
                });

            } else {
                resApi.status(404).send("الخطأ: خط الحافلة غير موجود");
            }

        });

        //        const sql = "update drivers_info set is_verified='true' where id=" + req.params.id;

    },
    deleteBusOrder: (req, resApi) => {
        db.query("SELECT id_bus from drivers_info where id=" + req.params.id, (err, res) => {
            if (err) throw err;
            console.log(res.rows.length);
            if (res.rows.length > 0) {
                db.query("delete from buses_info where id=" + res.rows[0].id_bus, (err, res) => {
                    if (err) throw err;
                    db.query("delete from drivers_info where id=" + req.params.id, (err, res) => {
                        if (err) throw err;
                        resApi.send("done");
                    });
                });
            } else {
                resApi.sendStatus(204);
            }
        });
    },
    driverInitLogin: (req, resApi) => {
        const phone = req.body.phone;
        const pass = req.body.pass;
        const push_token = req.body.push_token;
        db.query("SELECT COUNT(*) FROM drivers_info WHERE phone='" + phone + "'", (err, res) => {
            if (err) throw err;
            if (res.rows[0].count == 0) {
                resApi.status(404).send("الخطأ: رقم الهاتف المدخل غير صحيح");
            } else {
                db.query("SELECT pass FROM drivers_info WHERE phone='" + phone + "'", (err, res) => {
                    if (err) throw err;
                    if (isMatch(pass, res.rows[0].pass)) {
                        const ACCESS_TOKEN = jwt.sign({
                            phone: phone,
                            pass: pass
                        }, ACCESS_TOKEN_SECRET);
                        resApi.send(ACCESS_TOKEN);
                    } else {
                        resApi.status(400).send("الخطأ: كلمة المرور المدخلة غير صحيحة");

                    }

                });

            }
        });
        //ty
    },
    driverAutoLogin: (req, resApi) => {
        var os=req.body.os;
        var app_version=req.body.version;
        var drivers;
        var bus;
        var route;
//        console.log('current os is '+ os+' and version is '+app_version);
        db.query("SELECT id,id_bus,phone FROM drivers_info WHERE id_bus=(SELECT id_bus FROM drivers_info where phone='" + req.payload.phone + "')", (err, res) => {
            if (err) throw err;
            const id_bus = res.rows[0].id_bus;
            drivers = res.rows;
            db.query(os=='android'?'SELECT android_version FROM constants':'SELECT ios_version FROM constants', (err, res) => {
             if (err) throw err;
var server_version=os=='android'?res.rows[0].android_version:res.rows[0].ios_version;
//console.log('server_version is:'+server_version);
var is_need_update=compareVersions(server_version, app_version)>0;
//console.log('is_need_update is:'+is_need_update);
if(!is_need_update){
            db.query("SELECT * FROM buses_info WHERE id=" + id_bus, (err, res) => {
                if (err) throw err;
                bus = res.rows[0];
                if (res.rows[0].is_verified) {
                    db.query("SELECT * FROM routes_info WHERE id=" + res.rows[0].id_route, (err, res) => {
                        if (err) throw err;
                        route = res.rows[0];
                        resApi.status(200).send({
                            "route": route,
                            "bus": bus,
                            "drivers": drivers
                        });
                    });
                } else {
                    resApi.status(403).send('الخطأ: الحساب غير مفعل');
                }

            });
            }else{
             resApi.status(428).send('الخطأ: هنالك تحديث جديد للتطبيق يتوجب عليك تحميله');
            }
            });
        });
    },
    updateDriverPass: (req, resApi) => {
        const phone = req.payload.phone;
        const pass = encrypt(req.body.new_pass);
        db.query("UPDATE drivers_info SET pass = '" + pass + "' WHERE phone='" + phone + "'", (err, res) => {
            if (err) throw err;
            const ACCESS_TOKEN = jwt.sign({
                phone: phone,
                pass: pass
            }, ACCESS_TOKEN_SECRET);
            resApi.send(ACCESS_TOKEN);
        });
    },
    sendSMS: (req, resApi) => {
     db.query("SELECT phone FROM drivers_info WHERE phone='" + req.body.phone + "'", (err, res) => {
               if (err || res.rows.length==0) {
                              resApi.status(404).send("الخطأ: رقم الهاتف غير مسجل");
                             }else{
                                 var generatedToken = phoneToken(4, {
                                         type: 'string'
                                     })
                                     console.log(generatedToken)
                                     sendSMSToPhone("كود التحقق: " + generatedToken, req.body.phone);
                                     /// ------------------------------- send generatedToken to phone by relans sms
                                     resApi.send(encrypt(generatedToken + ""))
                             }
               });


    },
    checkSMS: (req, resApi) => {
        if (isMatch(req.body.code, req.body.hash)) {
        console.log("SELECT pass FROM drivers_info WHERE phone='" + req.body.phone + "'");
            db.query("SELECT pass FROM drivers_info WHERE phone='" + req.body.phone + "'", (err, res) => {
              console.log(res.rows.length);
                if (err || res.rows.length==0) {
                 resApi.status(404).send("الخطأ: رقم الهاتف غير مسجل");
                }else{
                                const ACCESS_TOKEN = jwt.sign({
                                    phone: req.body.phone,
                                    pass: decrypt(res.rows[0].pass)
                                }, ACCESS_TOKEN_SECRET);
                                resApi.send(ACCESS_TOKEN);

                }

            });

        } else {
               resApi.status(400).send("الخطأ: الكود المدخل غير صحيح");
        }
    },
    addDriver: (req, resApi) => {
        const mainPhone = req.payload.phone;
        const phone = req.body.phone;
        const encrypt_pass = encrypt(req.body.pass);
        console.log(mainPhone);
        db.query("INSERT INTO drivers_info (id_bus,phone,pass) VALUES((SELECT id_bus FROM drivers_info WHERE phone='" + mainPhone + "'),'" + phone + "','" + encrypt_pass + "')", (err, res) => {
            if (err) {
                const errMsg = err.message;
                console.log(errMsg);
                if (errMsg.includes('unique constraint')) {
                    resApi.status(400).send("الخطأ: رقم الهاتف مسجل مسبقا, يجب التسجيل برقم مختلف");
                } else {
                    resApi.status(500).send("الخطأ: يوجد مشكلة في بيانات الحافلة");
                }
            } else {
                executeQuery("UPDATE buses_info SET drivers_count=(drivers_count+1) WHERE id=(SELECT id_bus from drivers_info WHERE phone='" + phone + "') ");
                   selectQuery("SELECT id,id_bus,phone FROM drivers_info WHERE phone='"+phone+"'", resApi);

            }
        });
    },
    deleteDriver: (req, resApi) => {
        const authPhone = req.payload.phone;
        const id_driver_deleted = req.params.id;
        db.query("SELECT id_bus,id FROM drivers_info WHERE phone='" + authPhone + "';", (err, res) => {
            if (err || res.length==0) throw err;
            if (res.rows[0].id == id_driver_deleted) {
                resApi.status(400).send("الخطأ: لا يمكنك حذف حسابك");
            } else {


                const id_bus = res.rows[0].id_bus;
                db.query("SELECT COUNT(id_bus) FROM drivers_info WHERE id_bus=" + id_bus, (err, res) => {
                    if (err || res.length==0) throw err;
                    const count = res.rows[0].count;
                    if (count > 1) {
                        executeQuery("DELETE FROM drivers_info WHERE id=" + id_driver_deleted + " and id_bus=" + id_bus);
                        resApi.sendStatus(200);
                    } else {
                        resApi.status(400).send("الخطأ: يجب الابقاء على سائق واحد على الاقل");
                    }
                });
            }
        });
    },
    getAllRoutes: (req, resApi) => {
        selectQuery("SELECT id,name,current_work_buses FROM routes_info WHERE is_live='true' ORDER BY id ASC;", resApi);

    },
    sendSuggestion: (req, resApi) => {
        insertIntoUniqeTable(req, resApi, "users_suggestions", {
            "id_user": req.payload.id,
            "msg": req.body.msg
        });
    },
    userInitLogin: (req, resApi) => {
     var os=req.body.os;
                var app_version=req.body.version;
                 db.query(os=='android'?'SELECT android_version FROM constants':'SELECT ios_version FROM constants', (err, res) => {
                     if (err) throw err;
        var server_version=os=='android'?res.rows[0].android_version:res.rows[0].ios_version;
         console.log('app_version is:'+app_version);
        console.log('server_version is:'+server_version);
        console.log('compareVersions(server_version, app_version) is:'+compareVersions(server_version, app_version));
        var is_need_update=compareVersions(server_version, app_version)>0;
        if(!is_need_update){
           db.query("INSERT INTO users_info(push_token) VALUES('" + req.body.push_token + "') RETURNING id;", (err, res) => {
                    if (err) throw err;
                    console.log(res.rows[0].id);
                    const ACCESS_TOKEN = jwt.sign({
                        id: res.rows[0].id
                    }, ACCESS_TOKEN_SECRET);
                    console.log('user token is'+ACCESS_TOKEN);

                    resApi.send(ACCESS_TOKEN);
                });
        }else{
         resApi.status(428).send('الخطأ: هنالك تحديث جديد للتطبيق يتوجب عليك تحميله');
        }

              });

        },
    userAutoLogin: (req, resApi) => {
         var os=req.body.os;
                    var app_version=req.body.version;
                     db.query(os=='android'?'SELECT android_version FROM constants':'SELECT ios_version FROM constants', (err, res) => {
                         if (err) throw err;
            var server_version=os=='android'?res.rows[0].android_version:res.rows[0].ios_version;
             console.log('app_version is:'+app_version);
            console.log('server_version is:'+server_version);
            console.log('compareVersions(server_version, app_version) is:'+compareVersions(server_version, app_version));
            var is_need_update=compareVersions(server_version, app_version)>0;
            if(!is_need_update){
        resApi.sendStatus(200);
         }else{
             resApi.status(428).send('الخطأ: هنالك تحديث جديد للتطبيق يتوجب عليك تحميله');
            }

                  });


    },

    deleteUser: (req, resApi) => {
        executeQuery("DELETE FROM users_suggestions WHERE id_user=" + req.payload.id);
        executeQuery("DELETE FROM users_info WHERE id=" + req.payload.id, resApi);
        //                           db.query("SELECT id_bus from drivers_info where id=" + req.params.id, (err, res) => {
        //                             if (err) throw err;
        //                             console.log(res.rows.length);
        //                             if(res.rows.length>0){
        //                               db.query("delete from buses_info where id=" + res.rows[0].id_bus, (err, res) => {
        //                                 if (err) throw err;
        //                                   db.query("delete from drivers_info where id=" + req.params.id, (err, res) => {
        //                                       if (err) throw err;
        //                                       resApi.send("done");
        //                                   });
        //                               });
        //                               }else{
        //                               resApi.sendStatus(204);
        //                               }
        //                           });
    },
    userInitMap: (req, resApi) => {
        const id_user = req.payload.id;
        const id_route = req.body.id_route;
//        selectQuery("select * from routes_info where id=" + id_route,resApi);
        db.query("select * from routes_info where id=" + id_route, (err, res) => {
            if (err) throw err;
//            const path = res.rows[0].path;
//            const coord = res.rows[0].coord;
//            const zoom = res.rows[0].zoom;
//            resApi.json({
//                "id_user": id_user,
//                "path": path,
//                "coord": coord,
//                "zoom": zoom,
//                "buses_temp_info": tempInfo.getBusesTempInfo(id_route),
//            });
//        });

 resApi.json({
            "user": {"id_user": id_user},
 "route": res.rows,
            "buses_temp_info": tempInfo.getBusesTempInfo(id_route)
        });
         });
    },
    driverInitMap: (req, resApi) => {
        const id_route = req.body.id_route;
        resApi.json({
            "users_temp_info": tempInfo.getUsersTempInfo(id_route),
            "buses_temp_info": tempInfo.getBusesTempInfo(id_route)
        });

    },
}
//----------------------------------------------------




//------------------------------------------------
function createIdForTable(tableName) {
    const sql = 'select count(*) from ' + tableName;
    return new Promise((resolve, reject) => {
        db.query(sql, (err, result) => {
            if (err) {
                return reject(err);
            }
            resolve(result);
        });
    });
}

function executeQuery(sql, resApi) {
    db.query(sql, (err, res) => {
        if (err) throw err;
        if (isDefined(resApi)) {
            resApi.send("done");
        }

    });
}

function isDefined(value) {
    return typeof value != 'undefined';
}

function selectQuery(sql, resApi) {
    db.query(sql, (err, res) => {
        if (err) throw err;
        resApi.send(res.rows);
    });
}

function insertIntoTable(req, resApi, tableName, jsonArray) {
    createIdForTable(tableName).then((result) => {
        const id = (parseInt(result.rows[0].count) + parseInt(1));
        let columns = "id";
        let numbers = "$1";
        let iter = 2;
        let params = [id];

        for (var k in jsonArray) {
            params.push(jsonArray[k]);
            columns += "," + k;
            numbers += ",$" + iter;
            iter += 1;
        }
        const sql = "INSERT INTO " + tableName + "(" + columns + ") values(" + numbers + ");";
        db.query(sql, params, (err, res) => {
            if (err) throw err;
            resApi.send("done");
        });
    }).catch((err) => {
        throw err;
    });
}

function insertIntoUniqeTable(req, resApi, tableName, json) {
    var keys;
    var values;
    if (json != null) {
        keys = Object.keys(json);
        values = Object.values(json);
    } else {
        keys = Object.keys(req.body);
        values = Object.values(req.body);
    }
    var length = keys.length;
    var columns = (keys + "");
    var str = "";
    for (var i = 0; i < length; i++) {
        str += "'" + values[i] + "'";
        if (i != length - 1) {
            str += ",";
        }
    }
    var SQL = "INSERT INTO " + tableName + "(" + keys.toString() + ") VALUES(" + str + ");"
    executeQuery(SQL, resApi);
}

function sendSMSToPhone(sms, phone) {
    request.post('https://platform.releans.com/api/message/send').form({
        senderId: 'VZ7k1oYq9wdL8nrdjPXgEBG3Q',
        message: sms,
        mobileNumber: phone
    }).auth(null, null, true, 'd9b6a5f3bfb3e99a55e9482ca79cb1a3');
}

