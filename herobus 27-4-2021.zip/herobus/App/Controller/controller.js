const express = require('express');
const router = express.Router();
const service=require('../Service/service')



router.get('/drivers/test', service.test);
router.post('/buses/order/add', service.addBusOrder);
router.get('/buses/order/all', service.getAllBusesOrders);
router.post('/buses/order/accept', service.acceptBusOrder);
router.delete('/buses/order/delete/:id', service.deleteBusOrder);
router.post('/drivers/initlogin', service.driverInitLogin);
router.post('/drivers/autologin',service.driverAuthToken, service.driverAutoLogin);
router.put('/drivers/updatepass',service.driverAuthToken, service.updateDriverPass);
router.post('/drivers/sms/send', service.sendSMS);
router.post('/drivers/sms/check', service.checkSMS);
router.post('/drivers/adddriver',service.driverAuthToken, service.addDriver);
router.delete('/drivers/deletedriver/:id',service.driverAuthToken, service.deleteDriver);
router.post('/drivers/initmap',service.driverAuthToken, service.driverInitMap);
router.get('/drivers/orders/all', service.getAllBusesOrders);

router.get('/users/getallroutes', service.getAllRoutes);
router.post('/users/sendsuggestion',service.userAuthToken, service.sendSuggestion);
router.post('/users/initlogin', service.userInitLogin);
router.post('/users/autologin',service.userAuthToken, service.userAutoLogin);
router.delete('/users/delete',service.userAuthToken, service.deleteUser);
router.post('/users/initmap',service.userAuthToken, service.userInitMap);

//router.get('/drivers/orders/accept', service.acceptBusOrder);
//router.get('/drivers/orders/reject', service.rejectBusOrder);

//--------------
//router.get('/buses/all', service.getAllBuses);
//router.post('/updateuser', service.updateUser);
//router.get('/orders/all', service.getAllOrders);
//router.post('/orders/accept/:id', service.acceptOrder);
//router.delete('/orders/delete/:id', service.deleteOrder);
/// Add map controller
/// Add push notification controller



module.exports = router;
