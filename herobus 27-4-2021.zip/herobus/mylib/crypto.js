const crypto = require('crypto');

const algorithm = 'aes-256-ctr';
const secretKey = 'vOVH6sdmpNWjRRIqCc7rdxs01lwHzfr3';
const iv = crypto.randomBytes(16);

const encrypt = (text) => {

    const cipher = crypto.createCipheriv(algorithm, secretKey, iv);

    const encrypted = Buffer.concat([cipher.update(text), cipher.final()]);

    return  iv.toString('hex')+"."+encrypted.toString('hex');

};

const decrypt = (hash) => {
const splitStr=hash.split(".");
const iv=splitStr[0];
const content=splitStr[1];

//console.log(iv);
    const decipher = crypto.createDecipheriv(algorithm, secretKey, Buffer.from(iv, 'hex'));

    const decrpyted = Buffer.concat([decipher.update(Buffer.from(content, 'hex')), decipher.final()]);

    return decrpyted.toString();
};
const isMatch = (pass,hash) => {
const passFromHach=decrypt(hash);
    return  pass==passFromHach;

};
module.exports = {
    encrypt,
    decrypt,
    isMatch
};