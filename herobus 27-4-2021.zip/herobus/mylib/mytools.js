const express = require('express');

class mytools{


    // function createIdForTable(tableName) {
    //     client1.query(`select count(*) from ${tableName}`, (err, res) => {
    //         if (err) throw err;
    //          a=res.rows[0].count + 1;
    //         console.log(parseInt(res.rows[0].count) + parseInt(1));
    //         return parseInt(res.rows[0].count)+ 1;
    //     });
    // }

}