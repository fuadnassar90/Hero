const express = require('express');
const app = express();
const { Client } = require('pg');

var db = null;

const client = new Client({
    user: "xgqzhefkactbsh",
    password: "ace3704fd9dfe39f63683b71a177105e7da61d3a6bdee7448bb17995550af157",
    host: "ec2-52-30-161-203.eu-west-1.compute.amazonaws.com",
    port: "5432",
    database: "duvro1hdk5ach",
    ssl: {
        rejectUnauthorized: false
    }
});

class dbConnection {
constructor(){

}
 postgresjdbcTeamplate() {
    if (db == null) {
        console.log("the db is null");
        client.connect();
        db = client;
        return client;
    }
    return db;
}

}

module.exports=dbConnection;